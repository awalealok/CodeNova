# INKLOOM AI Frontend Setup

The Next.js frontend lives in `frontend/` and calls the FastAPI backend through the shared API client in `src/lib/api.ts`.

## Local development (Windows / PowerShell)

From the repository root:

```powershell
Set-Location .\frontend
Copy-Item .env.example .env.local
npm ci
npm run dev
```

The local API URL is configured as `NEXT_PUBLIC_API_URL=http://localhost:8000`. Start the backend separately from the repository root:

```powershell
python -m uvicorn backend.main:app --reload --host 127.0.0.1 --port 8000
```

For local development without signing in, use `APP_ENV=development` and `DEMO_AUTH_MODE=true` in the backend `.env`, and `NEXT_PUBLIC_DEMO_AUTH_MODE=true` in `frontend/.env.local`. Restart both services after changing the flags. Demo mode is development-only; production builds and non-development backend environments do not enable the bypass. The backend reuses or creates a local demo user and allows protected API calls without a session token. Logging out returns the frontend to the login page; signing in again accepts any non-empty text credentials. Set both demo flags to `false` to test normal authentication.

## API and session behavior

`NEXT_PUBLIC_API_URL` is the backend origin without a trailing slash. The shared API client sends requests with `credentials: "include"` so the browser can use the backend's HttpOnly session cookie. Do not store session tokens in browser storage.

For production, set `NEXT_PUBLIC_API_URL=https://inkloom-intelligence.onrender.com` in Vercel and set the matching explicit `CORS_ORIGINS` and `FRONTEND_BASE_URL` values in Render. The backend sets production cookies to `Secure`, `HttpOnly`, and `SameSite=None` for these different hosting domains. Third-party-cookie restrictions can still block this design in some browsers; use a same-site custom domain or same-origin API proxy if that occurs.

## Checks

Run from `frontend/`:

```powershell
npm test
npm run lint
npm run build
```
