import uuid

from alembic import command
from alembic.config import Config
from sqlalchemy import create_engine, inspect, text
from sqlalchemy.engine import URL
from sqlalchemy.orm import Session

from backend.database.connection import Base
from backend.models import Workspace


def test_bootstrap_creates_registered_tables_and_preserves_existing_rows(
    tmp_path, monkeypatch
):
    database_url = URL.create(
        "sqlite",
        database=str(tmp_path / "migration-test.db"),
    )
    existing_engine = create_engine(database_url)
    Base.metadata.tables["workspaces"].create(existing_engine)
    workspace_id = uuid.uuid4()
    with Session(existing_engine) as db:
        db.add(
            Workspace(
                id=workspace_id,
                name="Existing workspace",
                slug=f"existing-{workspace_id.hex}",
            )
        )
        db.commit()
    existing_engine.dispose()

    monkeypatch.setenv(
        "ALEMBIC_DATABASE_URL",
        database_url.render_as_string(hide_password=False),
    )
    config = Config("backend/alembic.ini")
    command.upgrade(config, "head")
    command.upgrade(config, "head")

    migrated_engine = create_engine(database_url)
    try:
        schema = inspect(migrated_engine)
        table_names = set(schema.get_table_names())
        assert set(Base.metadata.tables).issubset(table_names)
        for table_name, table in Base.metadata.tables.items():
            actual_columns = {
                column["name"] for column in schema.get_columns(table_name)
            }
            assert {column.name for column in table.columns}.issubset(actual_columns)
            actual_indexes = {
                index["name"] for index in schema.get_indexes(table_name)
            }
            assert {index.name for index in table.indexes}.issubset(actual_indexes)
        with migrated_engine.connect() as connection:
            assert connection.execute(
                text("SELECT version_num FROM alembic_version")
            ).scalar_one() == "0001_safe_schema_bootstrap"
        with Session(migrated_engine) as db:
            assert db.get(Workspace, workspace_id).name == "Existing workspace"
    finally:
        migrated_engine.dispose()
