import logging
from unittest.mock import Mock

from backend.database.connection import check_database_connection


def test_database_connection_failure_is_logged_without_error_details(
    caplog, monkeypatch
):
    import backend.database.connection as connection

    failing_engine = Mock()
    failing_engine.connect.side_effect = RuntimeError("sensitive connection detail")
    monkeypatch.setattr(connection, "engine", failing_engine)
    monkeypatch.setattr(connection.logger, "disabled", False)

    with caplog.at_level(logging.ERROR):
        assert check_database_connection() is False

    assert "Database connection check failed (RuntimeError)." in caplog.text
    assert "sensitive connection detail" not in caplog.text
