import { redirect } from "next/navigation";

export default function Home() {
  redirect(
    process.env.NODE_ENV === "development" &&
      process.env.NEXT_PUBLIC_DEMO_AUTH_MODE === "true"
      ? "/dashboard"
      : "/login",
  );
}