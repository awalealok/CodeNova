import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { vi } from "vitest";

const { push, replace, signIn, setSessionAuthenticated } = vi.hoisted(() => ({
  push: vi.fn(),
  replace: vi.fn(),
  signIn: vi.fn(),
  setSessionAuthenticated: vi.fn(),
}));

vi.mock("next/navigation", () => ({
  useRouter: () => ({ push, replace }),
}));

vi.mock("@/lib/api", () => ({
  DEMO_AUTH_MODE: true,
  setSessionAuthenticated,
  signIn,
}));

import LoginPage from "./page";

describe("LoginPage", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    signIn.mockResolvedValue({ user: { id: "demo-user" } });
  });

  it("renders the sign-in form and CTA", () => {
    render(<LoginPage />);

    expect(screen.getByText("Sign in to your workspace")).toBeInTheDocument();
    expect(screen.getByLabelText("Email")).toBeInTheDocument();
    expect(screen.getByLabelText("Password")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: /need an account\?/i })).toBeInTheDocument();
  });

  it("accepts arbitrary credentials and redirects to the dashboard in demo mode", async () => {
    render(<LoginPage />);

    fireEvent.change(screen.getByLabelText("Email"), {
      target: { value: "not-an-email" },
    });
    fireEvent.change(screen.getByLabelText("Password"), {
      target: { value: "x" },
    });
    fireEvent.click(screen.getByRole("button", { name: /sign in/i }));

    await waitFor(() => {
      expect(signIn).toHaveBeenCalledWith("not-an-email", "x");
      expect(setSessionAuthenticated).toHaveBeenCalledWith(true);
      expect(push).toHaveBeenCalledWith("/dashboard");
    });
  });
});
